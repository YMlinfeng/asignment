#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    HW2.2.3_关于行人车辆和自行车.py
@time:    2024-01-10 1:18
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
# -*- coding:utf-8 -*-
import logging
import os
import sys
from argparse import ArgumentParser, SUPPRESS
from time import time

import cv2
from openvino.inference_engine import IENetwork, IECore

logging.basicConfig(format="[ %(levelname)s ] %(message)s", level=logging.INFO, stream=sys.stdout)
log = logging.getLogger()


def build_argparser():
    parser = ArgumentParser(add_help=False)
    args = parser.add_argument_group('Options')
    args.add_argument('-h', '--help', action='help', default=SUPPRESS, help='显示此帮助消息和退出')
    args.add_argument("-m", "--model", help="具有经过训练的模型的.xml文件的路径",
                      default='vehicle-detection-adas-binary-0001.xml', type=str)
    # vehicle-detection-adas-binary-0001.xml
    # vehicle-license-plate-detection-barrier-0106.xml
    # vehicle-detection-adas-0002.xml
    args.add_argument("-i", "--input", help="图像/视频文件的路径。（指定要使用的“cam”->摄像机）", default='cam', type=str)
    args.add_argument("-l", "--cpu_extension",
                      help="可选。CPU自定义层需要。与内核实现共享库的绝对路径。", type=str,
                      default='C:/Users/yuki/Documents/Intel/OpenVINO/inference_engine_samples_build/intel64/Release/cpu_extension.dll')
    args.add_argument("-d", "--device",
                      help="可选。指定要推断的目标设备；可接受CPU、GPU、FPGA、HDDL或MYRIAD。示例将为指定的设备寻找合适的插件。默认值为CPU",
                      default="GPU", type=str)
    args.add_argument("--labels", help="可选。标签映射文件", default='car.names', type=str)
    args.add_argument("-t", "--prob_threshold", help="可选。检测滤波的概率阈值",
                      default=0.5, type=float)
    args.add_argument("-iout", "--iou_threshold", help="可选。重叠检测滤波的联合阈值交叉", default=0.4, type=float)
    args.add_argument("-ni", "--number_iter", help="可选。推理迭代次数", default=1, type=int)
    args.add_argument("-pc", "--perf_counts", help="可选。演示性能计数器", default=False,
                      action="store_true")
    args.add_argument("-r", "--raw_output_message", help="可选。输出推断结果原始值显示",
                      default=False, action="store_true")
    return parser


def main():
    args = build_argparser().parse_args()

    model_xml = args.model
    model_bin = os.path.splitext(model_xml)[0] + ".bin"

    # ------------- 1. 指定设备和加载扩展库的插件初始化(如果指定)-------------
    log.info("创建推理引擎...")
    ie = IECore()
    if args.cpu_extension and 'CPU' in args.device:
        ie.add_extension(args.cpu_extension, "CPU")

    # -------------------- 2. 读取模型优化器生成的IR（.xml和.bin文件） --------------------
    log.info("加载网络文件:\n\t{}\n\t{}".format(model_xml, model_bin))
    net = IENetwork(model=model_xml, weights=model_bin)

    # ---------------------------------- 3. 为支持特定层加载CPU扩展 ------------------------------
    if "CPU" in args.device:
        supported_layers = ie.query_network(net, "CPU")
        not_supported_layers = [l for l in net.layers.keys() if l not in supported_layers]
        if len(not_supported_layers) != 0:
            log.error("指定设备的插件不支持以下层 {}:\n {}".
                      format(args.device, ', '.join(not_supported_layers)))
            log.error("请尝试使用 -l 在示例的命令行参数中指定cpu扩展库路径 "
                      "或 --cpu_extension 命令行参数")
            sys.exit(1)

    # ---------------------------------------------- 4. 准备输入 -----------------------------------------------
    log.info("准备输入")
    input_blob = next(iter(net.inputs))
    out_blob = next(iter(net.outputs))  # 后面添加

    #  默认批量是1
    net.batch_size = 1

    # 读取并预处理输入图像
    n, c, h, w = net.inputs[input_blob].shape

    if args.labels:
        with open(args.labels, 'r') as f:
            labels_map = [x.strip() for x in f]
    else:
        labels_map = None

    input_stream = 0 if args.input == "cam" else args.input

    is_async_mode = True  # 异步

    # cap = cv2.VideoCapture(input_stream) #project2_video.mp4
    cap = cv2.VideoCapture('carvideo.mp4')  # car_test1.mp4 car_1.bmp

    initial_w = cap.get(3)
    initial_h = cap.get(4)

    number_input_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))  # 获得总视频的总帧数,摄像机 是-1，视频是 大于0,图片是 1

    number_input_frames = 1 if number_input_frames != -1 and number_input_frames < 0 else number_input_frames

    wait_key_code = 1

    # 图片中的帧数为1，将按周期读取。同步模式是这种情况下的默认值
    if number_input_frames != 1:
        ret, frame = cap.read()
    else:
        is_async_mode = False  # 如果是图片
        wait_key_code = 0

    # ----------------------------------------- 5. 将模型加载到插件 -----------------------------------------
    log.info("将模型加载到插件")
    exec_net = ie.load_network(network=net, num_requests=2, device_name=args.device)

    cur_request_id = 0
    next_request_id = 1
    render_time = 0
    parsing_time = 0
    # ----------------------------------------------- 6. Doing inference -----------------------------------------------
    log.info("开始推断...")
    print("要关闭应用程序，请按此处的“CTRL+C”或切换到输出窗口并按ESC键")
    print("要在同步/异步模式之间切换，请在“输出”窗口中按TAB键")
    while cap.isOpened():

        if is_async_mode:
            ret, next_frame = cap.read()
        else:
            ret, frame = cap.read()

        if not ret:
            break

        if is_async_mode:
            request_id = next_request_id
            in_frame = cv2.resize(next_frame, (w, h))
        else:
            request_id = cur_request_id
            in_frame = cv2.resize(frame, (w, h))

        # 将输入框调整为网络大小
        in_frame = in_frame.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        in_frame = in_frame.reshape((n, c, h, w))

        # 开始推断
        start_time = time()
        exec_net.start_async(request_id=request_id, inputs={input_blob: in_frame})  # input_blob 输入层名
        det_time = time() - start_time  # 推理时间
        origin_im_size = frame.shape[:-1]

        if exec_net.requests[cur_request_id].wait(-1) == 0:  # 返回ok状态才解析
            res = exec_net.requests[cur_request_id].outputs[out_blob]  # layer_name, out_blob

            for obj in res[0][0]:
                if obj[2] > args.prob_threshold:  # obj[2] : conf
                    xmin = int(obj[3] * initial_w)
                    ymin = int(obj[4] * initial_h)
                    xmax = int(obj[5] * initial_w)
                    ymax = int(obj[6] * initial_h)
                    class_id = int(obj[1])

                    # color = (min(class_id * 12.5, 255), min(class_id * 7, 255), min(class_id * 5, 255))
                    cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (24, 225, 30), 2)
                    det_label = labels_map[class_id] if labels_map else str(class_id)
                    cv2.putText(frame, det_label + ' ' + str(round(obj[2] * 100, 1)) + ' %', (xmin, ymin - 7),
                                cv2.FONT_HERSHEY_COMPLEX, 0.6, (210, 230, 20), 1)

        # 另外一种方式
        # if exec_net.requests[cur_request_id].wait(-1) == 0: # 返回ok状态才解析
        #     output = exec_net.requests[cur_request_id].outputs # layer_name, out_blob
        #
        #     start_time = time()
        #     for layer_name, out_blob in output.items():
        #         for obj in out_blob[0][0]:
        #             if obj[2] > args.prob_threshold: #obj[2] : conf
        #                 xmin=int(obj[3] * initial_w)
        #                 ymin=int(obj[4] * initial_h)
        #                 xmax=int(obj[5] * initial_w)
        #                 ymax=int(obj[6] * initial_h)
        #                 class_id=int(obj[1])
        #                 print(class_id)
        #
        #                 # color = (min(class_id * 12.5, 255), min(class_id * 7, 255), min(class_id * 5, 255))
        #                 cv2.rectangle(frame, (xmin,ymin), (xmax,ymax), (24,225,30), 2)
        #                 det_label = labels_map[class_id] if labels_map else str(class_id)
        #                 cv2.putText(frame,det_label + ' ' + str(round(obj[2] * 100 , 1)) + ' %',(xmin,ymin - 7),
        #                             cv2.FONT_HERSHEY_COMPLEX,0.6,(210,230,20),1)

        # 在帧上绘制性能统计信息
        inf_time_message = "Inference time: N\A for async mode" if is_async_mode else \
            "Inference time: {:.3f} ms".format(det_time * 1e3)
        render_time_message = "OpenCV rendering time: {:.3f} ms".format(render_time * 1e3)
        async_mode_message = "Async mode is on. Processing request {}".format(cur_request_id) if is_async_mode else \
            "Async mode is off. Processing request {}".format(cur_request_id)
        parsing_message = "car parsing time is {:.3f}".format(parsing_time * 1e3)

        cv2.putText(frame, inf_time_message, (15, 15), cv2.FONT_HERSHEY_COMPLEX, 0.5, (200, 10, 10), 1)
        cv2.putText(frame, render_time_message, (15, 45), cv2.FONT_HERSHEY_COMPLEX, 0.5, (10, 10, 200), 1)
        cv2.putText(frame, async_mode_message, (10, int(origin_im_size[0] - 20)), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                    (10, 10, 200), 1)
        cv2.putText(frame, parsing_message, (15, 30), cv2.FONT_HERSHEY_COMPLEX, 0.5, (10, 10, 200), 1)

        start_time = time()
        cv2.imshow("DetectionResults", frame)
        render_time = time() - start_time

        if is_async_mode:
            cur_request_id, next_request_id = next_request_id, cur_request_id
            frame = next_frame

        key = cv2.waitKey(wait_key_code)

        # ESC key
        if key == 27:
            break
        # Tab key
        if key == 9:
            exec_net.requests[cur_request_id].wait()
            is_async_mode = not is_async_mode
            log.info("Switched to {} mode".format("async" if is_async_mode else "sync"))

    cv2.destroyAllWindows()
    del net
    del exec_net
    del ie


if __name__ == '__main__':
    sys.exit(main() or 0)
from openvino.runtime import Core
import cv2
import numpy as np
import time
import json

with open(r"utils\data.json", "r") as json_file:
    data = json.load(json_file)
def license_plate_detect(image, threshold=0.4):
    # 01 准备模型文件
    model_xml = "models\\horizontal-text-detection-0001.xml"
    model_weight = "models\\horizontal-text-detection-0001.bin"

    # 02_1 创建引擎
    ie = Core()

    # 02_2 从文件加载模型
    m = ie.read_model(model=model_xml, weights=model_weight)

    # 02_3 编译获得模型运行时，用于推理
    runtime_model = ie.compile_model(model=m, device_name="CPU")

    start = time.time()
    # 03 输入预处理
    input_layer = next(iter(runtime_model.inputs))
    n, c, h, w = input_layer.shape
    rows, cols, c = image.shape
    image = cv2.resize(image, (w, h), interpolation=cv2.INTER_LINEAR)
    image = image.transpose(2, 0, 1)
    input_data = np.expand_dims(image, 0).astype(np.float32)

    # 04 模型推理，得到推理结果
    outputs = runtime_model([input_data])

    print(f"total cost {time.time() - start}s")

    # 05 推理结果后处理，本例子中得到所有人脸的bounding box，并形成list返回
    image = image.transpose(1, 2, 0)
    boxes = []
    for item in outputs:
        for res in outputs[item]:
            if (res[4] > threshold):
                minx = int(res[0] * cols / w)
                miny = int(res[1] * rows / h)
                maxx = int(res[2] * cols / w)
                maxy = int(res[3] * rows / h)
                # cv2.rectangle(image,(minx,miny),(maxx,maxy),(255,0,0),2)

                boxes.append([minx, miny, maxx, maxy])
        break

    return boxes


# 这就完成了车牌检测

def license_recognition(image, threshold=0.3):
    # 01 准备模型文件
    model_xml = "models\\license-plate-recognition-barrier-0007.xml"
    model_weight = "models\\license-plate-recognition-barrier-0007.bin"

    # 02_1 创建引擎
    ie = Core()

    # 02_2 从文件加载模型
    m = ie.read_model(model=model_xml, weights=model_weight)

    # 02_3 编译获得模型运行时，用于推理
    runtime_model = ie.compile_model(model=m, device_name="CPU")

    start = time.time()
    # 03 输入预处理
    input_layer = next(iter(runtime_model.inputs))
    n,h,w,c = input_layer.shape
    rows, cols, c = image.shape
    image = cv2.resize(image, (w, h), interpolation=cv2.INTER_LINEAR)
    print(image.shape)
    # image = image.transpose(2, 0, 1)
    input_data = np.expand_dims(image, 0).astype(np.float32)

    # 04 模型推理，得到推理结果
    outputs = runtime_model([input_data])
    res=''
    for item in outputs:
        for nums in outputs[item]:
            for it in nums:
                if(it!=-1):
                    res+=data[str(it)]
    return res





# 这就完成了车牌检测

def main():
    image = cv2.imread("test\\img_1.png")
    text_boxes = license_plate_detect(image)
    for rect in text_boxes:
        cv2.rectangle(image, (rect[0], rect[1]), (rect[2], rect[3]), (0, 0, 255), 2)
        new_img = image[rect[1]:rect[3], rect[0]:rect[2],:]
        license_info=license_recognition(new_img)
        cv2.putText(image,license_info,(rect[0],rect[1]),0,1,(0,255,255),2)


    cv2.imshow("result", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()

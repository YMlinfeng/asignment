#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    HW2.1.1_补第二次作业第一题代码.py
@time:    2024-01-10 1:39
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
import cv2

# 打开摄像头
cap = cv2.VideoCapture(0)

while True:
    # 读取视频帧
    ret, frame = cap.read()

    # 如果读取失败，退出循环
    if not ret:
        break

    # 显示原始视频
    cv2.imshow('Original Video', frame)

    # 水平镜像
    flipped_horizontal = cv2.flip(frame, 1)
    cv2.imshow('Horizontal Flip', flipped_horizontal)

    # 垂直翻转
    flipped_vertical = cv2.flip(frame, 0)
    cv2.imshow('Vertical Flip', flipped_vertical)

    # 退出键为'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 释放资源
cap.release()
cv2.destroyAllWindows()

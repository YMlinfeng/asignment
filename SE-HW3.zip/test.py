#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    test.py
@time:    2024-01-09 23:54
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
# from openvino.inference_engine import IECore
#
# ie = IECore()
#
# for device in ie.available_devices:
#     print(device)


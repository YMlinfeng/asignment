from openvino.runtime import Core
import cv2
import numpy as np
import time
from judge import *


def face_detect(timg, threshold=0.4):
    # 01 准备模型文件
    facedetect_xml = "face-detection-retail-0004.xml"
    facedetect_weight = "face-detection-retail-0004.bin"

    # 02_1 创建引擎
    ie = Core()

    # 02_2 从文件加载模型
    m = ie.read_model(model=facedetect_xml, weights=facedetect_weight)

    # 02_3 编译获得模型运行时，用于推理
    runtime_model = ie.compile_model(model=m, device_name="CPU")

    # 03 输入预处理
    input_layer = next(iter(runtime_model.inputs))
    n, c, h, w = input_layer.shape  # batch_size,channel卷积神经网络模型
    rows, cols, c = timg.shape  # 处理
    timg = cv2.resize(timg, (w, h), interpolation=cv2.INTER_LINEAR)
    timg = timg.transpose(2, 0, 1)
    input_data = np.expand_dims(timg, 0).astype(np.float32)

    # 04 模型推理，得到推理结果
    outputs = runtime_model([input_data])
    # 05 推理结果后处理，本例子中得到所有人脸的bounding box，并形成list返回
    boxes = []
    for item in outputs:
        for res in outputs[item][0][0]:
            if res[2] > threshold:
                minx = int(res[3] * cols)
                miny = int(res[4] * rows)
                maxx = int(res[5] * cols)
                maxy = int(res[6] * rows)
                boxes.append([minx, miny, maxx, maxy])

    return boxes


def angle_detect(image, threshold=0.3):
    # 01 准备模型文件
    model_xml = "head-pose-estimation-adas-0001.xml"
    model_weight = "head-pose-estimation-adas-0001.bin"

    # 02_1 创建引擎
    ie = Core()

    # 02_2 从文件加载模型
    m = ie.read_model(model=model_xml, weights=model_weight)

    # 02_3 编译获得模型运行时，用于推理
    runtime_model = ie.compile_model(model=m, device_name="CPU")

    start = time.time()
    # 03 输入预处理
    input_layer = next(iter(runtime_model.inputs))
    n, c, h, w = input_layer.shape
    rows, cols, c = image.shape
    image = cv2.resize(image, (w, h), interpolation=cv2.INTER_LINEAR)
    image = image.transpose(2, 0, 1)
    input_data = np.expand_dims(image, 0).astype(np.float32)

    # 04 模型推理，得到推理结果
    outputs = runtime_model([input_data])
    yaw = outputs["angle_y_fc"][0][0]
    pitch = outputs["angle_p_fc"][0][0]
    roll = outputs["angle_r_fc"][0][0]
    return yaw, pitch, roll


def main():
    video = cv2.VideoCapture(0)
    video_writer=cv2.VideoWriter("res.avi",0, 20.0, (640, 480))
    yaw_num,pitch_num,rol_num=0,0,0
    while (True):
        ret, image = video.read()
        face_boxes = face_detect(image)
        for rect in face_boxes:
            cv2.rectangle(image, (rect[0], rect[1]), (rect[2], rect[3]), (0, 0, 255), 2)
            new_img = image[rect[1]:rect[3], rect[0]:rect[2], :]
            yaw, pitch, rol = angle_detect(new_img)
            yaw_num+=int(determine_turning(yaw))
            pitch_num+=int(determine_pitch(pitch))
            rol_num+=int(determine_head_tilt(rol))
            cv2.putText(image,"yaw_num:{}".format(yaw_num) , (rect[0], rect[1]), 0, 1, (255, 0, 0), 1)
            cv2.putText(image, "pitch_num:{}".format(pitch_num), (rect[0], rect[1] + 30), 0, 1, (255, 255, 0), 1)
            cv2.putText(image, "rol_num:{}".format(rol_num), (rect[0], rect[1] + 60), 0, 1, (0, 255, 0), 1)
            cv2.imshow("result", image)
            video_writer.write(image)
        if cv2.waitKey(1) == ord('q'):
            break

    video.release()
    video_writer.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()

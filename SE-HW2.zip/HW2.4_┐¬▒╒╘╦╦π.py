#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    HW2.4_开闭运算.py
@time:    2024-01-07 22:02
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
import cv2
import numpy as np

# 读取原始图像，转换为灰度图，并进行二值化处理
img = cv2.imread("table.png")
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, img_bin = cv2.threshold(img_gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

# 定义水平方向的卷积核，并对二值图进行开运算，得到水平线图
kernel_h = np.ones((1, 15), np.uint8)
img_h = cv2.morphologyEx(img_bin, cv2.MORPH_OPEN, kernel_h)

# 定义垂直方向的卷积核，并对二值图进行开运算，得到垂直线图
kernel_v = np.ones((15, 1), np.uint8)
img_v = cv2.morphologyEx(img_bin, cv2.MORPH_OPEN, kernel_v)

# 将水平线图和垂直线图相加，得到表格线图
img_line = img_h + img_v

# 显示或保存表格线图
cv2.imshow("img_line", img_line)
cv2.imwrite("img_line.png", img_line)
cv2.waitKey()


# 读取原始图像和表格线图
img = cv2.imread("table.png")
img_line = cv2.imread("img_line.png", 0)

# 在表格线图中找到所有的轮廓
contours, _ = cv2.findContours(img_line, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# 遍历轮廓列表
cell_id = 0 # 单元格编号
area_threshold = 1000 # 面积阈值
for c in contours:
    # 计算轮廓的外接矩形
    x, y, w, h = cv2.boundingRect(c)
    # 判断矩形的面积是否大于阈值
    if w * h > area_threshold:
        # 绘制矩形的边框
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        # 保存单元格对应的子图
        cell = img[y:y + h, x:x + w]
        cell_id += 1
        cv2.imwrite("cell_" + str(cell_id) + ".png", cell)

# 显示或保存带有矩形边框的原始图像
cv2.imshow("img", img)
cv2.imwrite("img.png", img)
cv2.waitKey()

#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    HW2.2_中国象棋棋盘.py
@time:    2024-01-07 20:39
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
# 导入opencv库
import cv2 as cv
import numpy as np

# 创建一个空白的图像，大小为800x800，颜色为白色

# img_width, img_height = 800, 800
# background_color = (255, 255, 255)  # 白色

img = np.array([[255] * 800] * 800, dtype=np.uint8) # 创建一个800x800的单通道矩阵，每个元素的值为255，即白色
img = cv.cvtColor(img, cv.COLOR_GRAY2BGR) # 将矩阵转换为BGR格式的图像，便于后续绘制棋盘

# 设置棋盘的行数和列数
rows = 10
cols = 9
# 设置棋盘的边距
margin = 50
# 设置棋盘的格子大小
cell_size = 80
# 设置棋盘的线条颜色和粗细
line_color = (0, 0, 0) # 黑色
line_width = 2
# 用循环画出棋盘的横线和竖线
for i in range(rows):
    # 计算横线的起点和终点的坐标
    start_point = (margin, margin + i * cell_size)
    end_point = (margin + (cols - 1) * cell_size, margin + i * cell_size)
    # 用cv.line函数画出横线
    cv.line(img, start_point, end_point, line_color, line_width)

for j in range(cols):
    # 计算竖线的起点和终点的坐标
    start_point = (margin + j * cell_size, margin)
    end_point = (margin + j * cell_size, margin + 4 * cell_size)
    cv.line(img, start_point, end_point, line_color, line_width)
for j in range(cols):
    start_point = (margin + j * cell_size, margin + 5 * cell_size)
    end_point = (margin + j * cell_size, margin + (rows - 1) * cell_size)
    # 用cv.line函数画出竖线
    cv.line(img, start_point, end_point, line_color, line_width)

cv.line(img, (margin, margin + 4 * cell_size), (margin, margin + 5 * cell_size), line_color, line_width)
cv.line(img, (margin + 8 * cell_size, margin + 4 * cell_size), (margin + 8 * cell_size, margin + 5 * cell_size), line_color, line_width)

# 用cv.line函数画出棋盘的斜线，即士和将的走法
cv.line(img, (margin + 3 * cell_size, margin), (margin + 5 * cell_size, margin + 2 * cell_size), line_color, line_width)
cv.line(img, (margin + 5 * cell_size, margin), (margin + 3 * cell_size, margin + 2 * cell_size), line_color, line_width)
cv.line(img, (margin + 3 * cell_size, margin + 7 * cell_size), (margin + 5 * cell_size, margin + 9 * cell_size), line_color, line_width)
cv.line(img, (margin + 5 * cell_size, margin + 7 * cell_size), (margin + 3 * cell_size, margin + 9 * cell_size), line_color, line_width)
# 设置棋盘的文字颜色和字体
text_color = (134, 231, 67)
font = cv.FONT_HERSHEY_SIMPLEX
cv.putText(img, "by22920202200774_mzj", (margin + 130, margin + 370), font, 1, text_color, 2)

# 用cv.putText函数写出棋盘的文字，即棋子的名称
# cv.putText(img, "ju", (margin + 0 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "ma", (margin + 1 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "xiang", (margin + 2 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "shi", (margin + 3 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "jiang", (margin + 4 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "shi", (margin + 5 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "xiang", (margin + 6 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "ma", (margin + 7 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "ju", (margin + 8 * cell_size, margin + 0 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "pao", (margin + 1 * cell_size, margin + 2 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "pao", (margin + 7 * cell_size, margin + 2 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "bing", (margin + 0 * cell_size, margin + 3 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "bing", (margin + 2 * cell_size, margin + 3 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "bing", (margin + 4 * cell_size, margin + 3 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "bing", (margin + 6 * cell_size, margin + 3 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "bing", (margin + 8 * cell_size, margin + 3 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "車", (margin + 0 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "馬", (margin + 1 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "相", (margin + 2 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "仕", (margin + 3 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "帅", (margin + 4 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "仕", (margin + 5 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "相", (margin + 6 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "馬", (margin + 7 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "車", (margin + 8 * cell_size, margin + 9 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "砲", (margin + 1 * cell_size, margin + 7 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "砲", (margin + 7 * cell_size, margin + 7 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "卒", (margin + 0 * cell_size, margin + 6 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "卒", (margin + 2 * cell_size, margin + 6 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "卒", (margin + 4 * cell_size, margin + 6 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "卒", (margin + 6 * cell_size, margin + 6 * cell_size), font, 1, text_color, 2)
# cv.putText(img, "卒", (margin + 8 * cell_size, margin + 6 * cell_size), font, 1, text_color, 2)
# 显示图像
cv.imshow("chessboard", img)
# 将图像保存
cv.imwrite('chessboard.jpg', img)
# 等待按键
cv.waitKey(0)
# 释放资源
cv.destroyAllWindows()


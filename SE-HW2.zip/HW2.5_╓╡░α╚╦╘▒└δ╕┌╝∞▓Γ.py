#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    HW2.5_值班人员离岗检测.py
@time:    2024-01-07 23:53
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
import numpy as np
import cv2

# 创建一个HOG对象
hog = cv2.HOGDescriptor()
# 设置HOG对象为默认的人体检测器
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# 打开视频文件或摄像头
cap = cv2.VideoCapture('one.mp4') # 0表示摄像头

while True:
    # 读取一帧图像
    ret, frame = cap.read()
    if not ret:
        break

    # 调整图像大小，加快检测速度
    frame = cv2.resize(frame, (640, 480))

    # 检测图像中的人体，返回每个人体的位置和置信度
    # 可以调整winStride和padding参数来改变检测窗口的步长和边缘填充
    # 也可以调整scale参数来改变图像金字塔的缩放比例
    (rects, weights) = hog.detectMultiScale(frame, winStride=(4, 4), padding=(8, 8), scale=1.05)

    # 如果没有检测到任何人体，就在画面中嵌入红色字体
    if len(rects) == 0:
        cv2.putText(frame, 'No one is on duty!', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    # 否则，就把每个人体标注为绿色
    else:
        for (x, y, w, h) in rects:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # 显示处理后的图像
    cv2.imshow('frame', frame)

    # 按q键退出循环
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 释放资源
cap.release()
cv2.destroyAllWindows()

#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    HW2.3_视频广告嵌入.py
@time:    2024-01-07 21:42
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
# 导入OpenCV库
import cv2

# 读取视频文件
cap = cv2.VideoCapture('mzjHJ.mp4')

# 获取视频的宽度和高度
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# 创建一个新的视频文件用于保存输出
out = cv2.VideoWriter('output.avi', cv2.VideoWriter_fourcc('M','J','P','G'), 30, (width, height))

# 读取广告图片，并调整大小和位置
img = cv2.imread('mzjLECTURE.jpg')
img = cv2.resize(img, (200, 150))
x = width - 200
y = 0

# 循环处理每一帧视频
while cap.isOpened():
    # 读取一帧视频
    ret, frame = cap.read()
    if ret:
        # 将广告图片和视频帧进行加权叠加，实现画中画的效果
        frame[y:y+150, x:x+200] = cv2.addWeighted(frame[y:y+150, x:x+200], 0.1, img, 0.9, 0)
        # 显示输出视频
        cv2.imshow('output', frame)
        # 将输出视频保存到新的文件中
        out.write(frame)
        # 控制视频的播放速度
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break
    else:
        break

# 释放资源
cap.release()
out.release()
cv2.destroyAllWindows()

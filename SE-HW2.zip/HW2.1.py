#!/usr/bin/env python  
# -*- coding:utf-8 -*-  
"""
@author:  Zj Meng
@file:    HW2.1.py
@time:    2024-01-06 11:49
@contact: ymlfvlk@gmail.com 
@desc: "Welcome contact me if any questions"

"""
# import cv2
#
# # 打开摄像头
# cap = cv2.VideoCapture(0)
#
# while True:
#     # 读取一帧
#     ret, frame = cap.read()
#
#     # 如果读取成功
#     if ret:
#         # 显示原始图像
#         cv2.imshow('Original', frame)
#
#         # 水平镜像
#         horizontal_flip = cv2.flip(frame, 1)
#         cv2.imshow('Horizontal Flip', horizontal_flip)
#
#         # 垂直翻转
#         vertical_flip = cv2.flip(frame, 0)
#         cv2.imshow('Vertical Flip', vertical_flip)
#
#     # 按下 'q' 键退出循环
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break
#
# # 释放摄像头并关闭所有窗口
# cap.release()
# cv2.destroyAllWindows()


import cv2
import numpy as np

# 定义棋盘大小和格子数量
board_size = (800, 640)
grid_nums = 15

# 创建空白图像并设置背景颜色为黑色
image = np.zeros(board_size, dtype=np.uint8)
image[:] = [0, 0, 0]

# 计算每个格子的边长
square_length = min(board_size[0], board_size[1]) // grid_nums

# 绘制横线
for i in range(grid_nums):
    start_point = (i * square_length, 0)
    end_point = ((i + 1) * square_length - 1, board_size[1] - 1)
    color = (255, 255, 255) if i % 2 == 0 else (0, 0, 0)
    thickness = int((start_point[0] / square_length) ** 2)
    cv2.line(image, start_point, end_point, color, thickness)

# 绘制竖线
for j in range(grid_nums):
    start_point = (0, j * square_length)
    end_point = (board_size[0] - 1, (j + 1) * square_length - 1)
    color = (255, 255, 255) if j % 2 != 0 else (0, 0, 0)
    thickness = int((start_point[1] / square_length) ** 2)
    cv2.line(image, start_point, end_point, color, thickness)

# 显示结果图片
cv2.imshow("Chinese Chess Board", image)
cv2.waitKey(0)
cv2.destroyAllWindows()